This program is making to simulate/calculate a model rocket orbit.

If you want to download it as a application, you can download it from the following URL.  
URL:https://jp.mathworks.com/matlabcentral/fileexchange/163506-model-rocket-orbit-calculator
